package com.dias.notesapp.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.dias.notesapp.R

class MainActivity : AppCompatActivity(R.layout.activity_main)