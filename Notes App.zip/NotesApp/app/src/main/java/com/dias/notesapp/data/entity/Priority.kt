package com.dias.notesapp.data.entity

enum class Priority {
    HIGH,
    MEDIUM,
    LOW
}